export type Gender = 'MALE' | 'FEMALE' | 'UNKNOWN'
export type MealType = 'BREAKFAST' | 'LUNCH' | 'DINNER' | 'SNACK' | 'OTHER'
export type PlanTarget = 'LOSE_FAT' | 'GAIN_MUSCLE' | 'MAINTAIN' | 'RECOMP'
