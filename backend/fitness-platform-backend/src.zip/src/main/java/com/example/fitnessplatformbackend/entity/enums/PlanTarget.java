package com.example.fitnessplatformbackend.entity.enums;

public enum PlanTarget {
    FAT_LOSS, MUSCLE_GAIN, MAINTAIN
}
