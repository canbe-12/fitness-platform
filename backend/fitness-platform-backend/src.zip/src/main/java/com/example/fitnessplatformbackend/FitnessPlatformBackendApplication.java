package com.example.fitnessplatformbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FitnessPlatformBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FitnessPlatformBackendApplication.class, args);
	}

}
