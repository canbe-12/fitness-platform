package com.example.fitnessplatformbackend.entity.enums;

public enum MealType {
    BREAKFAST, LUNCH, DINNER, SNACK
}
